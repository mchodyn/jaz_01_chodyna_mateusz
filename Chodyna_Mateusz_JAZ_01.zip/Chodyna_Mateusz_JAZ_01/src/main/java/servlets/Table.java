package servlets;

import java.io.IOException;
import java.text.DecimalFormat;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
@WebServlet("/wynik")
public class Table extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public void doPost(HttpServletRequest request,HttpServletResponse response) throws IOException
	{
			response.setContentType("text/html");
			//Dodatkowe zabezpieczenie jakby ktos edytowal htmla
			if (request.getParameter("kwotaKredytu").isEmpty() || request.getParameter("iloscRat").isEmpty() || 
				request.getParameter("oprocentowanie").isEmpty() || request.getParameter("oplataStala").isEmpty()
				|| request.getParameter("rodzajRat").isEmpty() ) {
				response.getWriter().append("Pola formularza nie mog� by� puste<br/>");
				response.getWriter().append("<a href='index.jsp'>Wr�c</a>");
				
			}
				
			 String rodzajRat = request.getParameter("rodzajRat");	
			 double kwotaKredytu=Double.parseDouble(request.getParameter("kwotaKredytu"));
			 int iloscRat=Integer.parseInt(request.getParameter("iloscRat"));
			 double oprocentowanie=Double.parseDouble(request.getParameter("oprocentowanie"));
			 double oplataStala=Double.parseDouble(request.getParameter("oplataStala"));
			 java.text.DecimalFormat df=new java.text.DecimalFormat();
			 df.setMaximumFractionDigits(2);
			 df.setMinimumFractionDigits(2);
			 response.getWriter().println("<head><style type=\"text/css\">table{border-collapse: collapse;} tr {border: 1px solid black;} td,th {text-align:center; border: 1px solid black;}</style></head><body>");
			 response.getWriter().println("<table>" + "<tr>" + "<th>Nr raty</th>" + "<th>Kwota kapita�u</th>" + "<th>Kwota odsetek</th>" + 
						"<th>Op�aty sta�e</th>" + "<th>Ca�kowita kwota raty</th>" + "</tr>");
				
			if(rodzajRat.equals("stala")) {
				double q=1+(oprocentowanie/1200);
				double rata=(kwotaKredytu*Math.pow(q,iloscRat))*(q-1)/(Math.pow(q, iloscRat)-1);
				double czescKapitalowa = kwotaKredytu/iloscRat;
				double czescOdsetkowa= rata-czescKapitalowa;
				for(int i=0; i<iloscRat; i++) {
					response.getWriter().println("<tr>");
					response.getWriter().println("<td>" + (i+1) + "." + "</td>");
					response.getWriter().println("<td>"+ df.format(czescKapitalowa) + "</td>");
					response.getWriter().println("<td>"+ df.format(czescOdsetkowa) + "</td>");
					response.getWriter().println("<td>"+ oplataStala + "</td>");
					response.getWriter().println("<td>"+ df.format(rata+oplataStala) + "</td>");
					response.getWriter().println("</tr>");
					}
				}
			if(rodzajRat.equals("malejaca")) {
				double czescKapitalowa= kwotaKredytu/iloscRat;
				double kwotaDoSplaty=kwotaKredytu;
				for(int i=0; i<iloscRat; i++) {
					double czescOdsetkowa=kwotaDoSplaty*oprocentowanie/1200;
					double rata= czescKapitalowa+czescOdsetkowa;
					response.getWriter().println("<tr>");
					response.getWriter().println("<td>" + (i+1) + "." + "</td>");
					response.getWriter().println("<td>"+ df.format(czescKapitalowa) + "</td>");
					response.getWriter().println("<td>"+ df.format(czescOdsetkowa) + "</td>");
					response.getWriter().println("<td>"+ oplataStala + "</td>");
					response.getWriter().println("<td>"+ df.format(rata+oplataStala) + "</td>");
					response.getWriter().println("</tr>");
					kwotaDoSplaty=kwotaDoSplaty-czescKapitalowa;	
					}
				}
				response.getWriter().println("</table>");
				response.getWriter().println("<form action=\"createPDF\" method=\"post\">" +
				"<input type='hidden' value='"+kwotaKredytu+"' name=\"kwotaKredytu\">\r\n" + 
				"<input type='hidden' value='"+iloscRat+"' name=\"iloscRat\">\r\n" + 
				"<input type='hidden' value='"+oprocentowanie+"' name=\"oprocentowanie\">\r\n" + 
				"<input type='hidden' value='"+oplataStala+"' name=\"oplataStala\">\r\n" + 
				"<input type='hidden' value='"+rodzajRat+"' name=\"rodzajRat\">\r\n" + 
				"<input type=\"submit\" value=\"Generuj PDF\">\r\n" +
				"</form>");
				response.getWriter().println("</body>");
		 }
		
		 
		
			
		
	}