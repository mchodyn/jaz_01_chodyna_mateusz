package servlets;
import java.io.*;
import java.util.ArrayList;

import javax.persistence.metamodel.IdentifiableType;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.itextpdf.*;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;

@WebServlet("/createPDF")
public class createPDF extends HttpServlet {
	
private static final long serialVersionUID = 1L;
	
	public void doPost(HttpServletRequest request,HttpServletResponse response) throws IOException{
		 String rodzajRat = request.getParameter("rodzajRat");
		 double kwotaKredytu=Double.parseDouble(request.getParameter("kwotaKredytu"));
		 int iloscRat=Integer.parseInt(request.getParameter("iloscRat"));
		 double oprocentowanie=Double.parseDouble(request.getParameter("oprocentowanie"));
		 double oplataStala=Double.parseDouble(request.getParameter("oplataStala"));
		 java.text.DecimalFormat df=new java.text.DecimalFormat();
		 df.setMaximumFractionDigits(2);
		 df.setMinimumFractionDigits(2);
		 ByteArrayOutputStream tempPDFstorage = new ByteArrayOutputStream();
		 
		Document pdf = new Document();
		try {
			PdfWriter.getInstance(pdf, tempPDFstorage );
		} catch (DocumentException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		pdf.open();
		PdfPTable table = new PdfPTable(5);
		//tworzenie naglowkow
		PdfPCell header = new PdfPCell();
		header.setBorderWidth(1);
		header.setBackgroundColor(BaseColor.BLUE);
		header.setPhrase(new Phrase("Nr raty"));
		table.addCell(header);
		PdfPCell header1 = new PdfPCell();
		header1.setBorderWidth(1);
		header1.setBackgroundColor(BaseColor.BLUE);
		header1.setPhrase(new Phrase("Kwota kapitału"));
		table.addCell(header1);
		PdfPCell header2 = new PdfPCell();
		header2.setBorderWidth(1);
		header2.setBackgroundColor(BaseColor.BLUE);
		header2.setPhrase(new Phrase("Kwota odsetek"));
		table.addCell(header2);
		PdfPCell header3 = new PdfPCell();
		header3.setBorderWidth(1);
		header3.setBackgroundColor(BaseColor.BLUE);
		header3.setPhrase(new Phrase("Opłaty stałe"));
		table.addCell(header3);
		PdfPCell header4 = new PdfPCell();
		header4.setBorderWidth(1);
		header4.setBackgroundColor(BaseColor.BLUE);
		header4.setPhrase(new Phrase("Całkowita kwota raty"));
		table.addCell(header4);
		
		if(rodzajRat.equals("malejaca")) {
			double czescKapitalowa = kwotaKredytu/iloscRat;
			for(int i=0; i<iloscRat; i++) {
				double czescOdsetkowa = kwotaKredytu*oprocentowanie/1200;
				double rata = czescKapitalowa+czescOdsetkowa;
				table.addCell(String.valueOf(i+1));
				table.addCell(String.valueOf(df.format(czescKapitalowa)));
				table.addCell(String.valueOf(df.format(czescOdsetkowa)));
				table.addCell(String.valueOf(oplataStala));
				table.addCell(String.valueOf(df.format(rata+oplataStala)));
				kwotaKredytu = kwotaKredytu - czescKapitalowa;	
				}
			}
		
		if(rodzajRat.equals("stala")) {
			double q=1+(oprocentowanie/1200);
			double rata=(kwotaKredytu*Math.pow(q,iloscRat))*(q-1)/(Math.pow(q, iloscRat)-1);
			double czescKapitalowa = kwotaKredytu/iloscRat;
			double czescOdsetkowa= rata-czescKapitalowa;
			for(int i=0; i<iloscRat; i++) {
				table.addCell(String.valueOf(i+1));
				table.addCell(String.valueOf(df.format(czescKapitalowa)));
				table.addCell(String.valueOf(df.format(czescOdsetkowa)));
				table.addCell(String.valueOf(oplataStala));
				table.addCell(String.valueOf(df.format(rata)));
				}
			}
		
		
		try {
			pdf.add(table);
		} catch (DocumentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		pdf.close();
		
		response.reset();
		response.setContentType("application/pdf");
		response.addHeader("Content-Disposition", "attachement; filename=raty.pdf");
		response.setContentLength((int)tempPDFstorage.size());
		
		byte[] pdfBytes = tempPDFstorage.toByteArray();
		ByteArrayInputStream pdfOut = new ByteArrayInputStream(pdfBytes);
		int bytes;
		while ((bytes = pdfOut.read()) != -1) {
			response.getOutputStream().write(bytes);
		}
		}
	}
	


